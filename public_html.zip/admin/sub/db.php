<?php
// admin/super/db.php
// Shared DB bootstrap for SUPER admin area
require_once __DIR__ . '/../../asset/db/config.php';
