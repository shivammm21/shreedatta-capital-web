<?php
@session_start();
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== 1) {
  header('Location: index.html');
  exit;
}
require_once __DIR__ . '/config/secret.php';
// Generate short, time-limited tokens (valid for 30 days)
$exp = time() + 30 * 24 * 60 * 60;
$tGold = make_short_token('g', $exp, $LINK_SECRET);
$tCash = make_short_token('c', $exp, $LINK_SECRET);
$tBike = make_short_token('b', $exp, $LINK_SECRET);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Dashboard - Shreedatta Capital</title>
  <meta name="description" content="Admin dashboard for Shreedatta Capital" />
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.9em' font-size='90'>📊</text></svg>">
  <link rel="stylesheet" href="asset/css/style.css">
  <style>
    /* Minimal modal styles scoped to dashboard */
    .hidden { display: none !important; }
    .modal { position: fixed; inset: 0; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; padding: 16px; z-index: 1000; }
    .modal-box { background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; width: 100%; max-width: 420px; padding: 18px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); }
    .modal-title { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
    .modal-text { color: #374151; font-size: 14px; margin: 0 0 14px; }
    .modal-actions { display: flex; gap: 10px; justify-content: flex-end; }
    .btn-danger { background:#dc2626; color:#fff; border: none; border-radius:10px; padding:10px 14px; cursor:pointer; }
    .btn-icon-delete { 
      background: transparent; 
      border: none; 
      padding: 8px; 
      cursor: pointer; 
      border-radius: 6px; 
      color: #6b7280; 
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .btn-icon-delete:hover { 
      background: #f3f4f6; 
      color: #dc2626; 
    }
    .btn-icon-delete:active { 
      transform: scale(0.95); 
    }
  </style>
</head>
<body class="dashboard">
  <div id="dashboard" role="main">
    <div class="dash-shell">
      <div class="dash-header">
        <div class="dash-title">
          <div class="badge" aria-hidden="true">
            <span>📊</span>
            <span>Admin Dashboard</span>
          </div>

          <h1 class="title" style="margin:0 0 0 8px;">Welcome, Shree Datta Capital</h1>
        </div>
        <button id="logout" class="btn btn-primary" type="button">Logout</button>
      </div>

      <div class="top-categories">
        <div class="category-card gold">
          <div class="category-title">Gold Draw</div>
          <div class="category-sub">Manage entries and results</div>
          <div class="category-meta"><span class="count-badge big" data-count-key="gold_registration">0</span> users filled</div>
          <div class="category-links">
            <a class="url" href="/link.php?t=<?php echo urlencode($tGold); ?>"></a>
            <button class="btn btn-secondary copy-btn" type="button">Copy</button>
          </div>
        </div>
        <div class="category-card cash">
          <div class="category-title">Cash Draw</div>
          <div class="category-sub">Payouts and records</div>
          <div class="category-meta"><span class="count-badge big" data-count-key="cash_registration">0</span> users filled</div>
          <div class="category-links">
            <a class="url" href="/link.php?t=<?php echo urlencode($tCash); ?>"></a>
            <button class="btn btn-secondary copy-btn" type="button">Copy</button>
          </div>
        </div>
        <div class="category-card bike">
          <div class="category-title">Bike Draw</div>
          <div class="category-sub">Participants and winners</div>
          <div class="category-meta"><span class="count-badge big" data-count-key="bike_registration">0</span> users filled</div>
          <div class="category-links">
            <a class="url" href="/link.php?t=<?php echo urlencode($tBike); ?>"></a>
            <button class="btn btn-secondary copy-btn" type="button">Copy</button>
          </div>
        </div>
      </div>

      <!-- User Search and Results -->
      <div class="user-section">
        <div class="user-search">
          <label for="user-search-input" class="sr-only">Search users</label>
          <input id="user-search-input" type="text" placeholder="Search users by name" />
        </div>
        <div class="user-filters">
          <button type="button" class="filter-btn" data-form="gold">Gold</button>
          <button type="button" class="filter-btn" data-form="bike">Bike</button>
          <button type="button" class="filter-btn" data-form="cash">Cash</button>
        </div>
        <div class="user-results">
          <table class="user-table">
            <colgroup>
              <col style="width: 28%" />
              <col style="width: 22%" />
              <col style="width: 29%" />
              <col style="width: 15%" />
            </colgroup>
            <thead>
              <tr>
                <th>User Name</th>
                <th>Form</th>
                <th>Date and Time</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="user-rows">
              <!-- populated by JS -->
            </tbody>
          </table>
          <div id="user-empty" class="user-empty" style="display:none;">No users found.</div>
        </div>
      </div>

      <div class="dash-footer"> <span id="year"></span> Shreedatta Capital. All rights reserved.</div>
    </div>
  </div>

  <!-- Confirm delete modal -->
  <div id="confirmModal" class="modal hidden" role="dialog" aria-modal="true" aria-labelledby="confirmTitle">
    <div class="modal-box">
      <div id="confirmTitle" class="modal-title">Delete entry?</div>
      <p class="modal-text">Are you sure you want to delete this entry? This action cannot be undone.</p>
      <div class="modal-actions">
        <button id="confirmCancel" type="button" class="btn">Cancel</button>
        <button id="confirmDelete" type="button" class="btn-danger">Delete</button>
      </div>
    </div>
  </div>

  <!-- Confirm logout modal -->
  <div id="logoutModal" class="modal hidden" role="dialog" aria-modal="true" aria-labelledby="logoutTitle">
    <div class="modal-box">
      <div id="logoutTitle" class="modal-title">Logout confirmation</div>
      <p class="modal-text">Are you sure you want to logout from the admin dashboard?</p>
      <div class="modal-actions">
        <button id="logoutCancel" type="button" class="btn">Cancel</button>
        <button id="logoutConfirm" type="button" class="btn-danger">Logout</button>
      </div>
    </div>
  </div>

  <script src="asset/js/app.js"></script>
</body>
</html>
